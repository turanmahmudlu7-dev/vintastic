import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Product = {
  id: string;
  name: string;
  price: number;
  discount?: number;
  category: string;
  sizes: string[];
  images: string[];
  description: string;
  materials: string;
  shippingInfo: string;
  inventory: number;
  isNew: boolean;
  isLimited: boolean;
  isBestSeller: boolean;
  collection?: string;
  createdAt: number;
};

export type OrderItem = {
  productId: string;
  name: string;
  price: number;
  size: string;
  quantity: number;
  image: string;
};

export type Order = {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  isWpVerified?: boolean;
  items: OrderItem[];
  total: number;
  status: 'PENDING' | 'FULFILLED' | 'CANCELLED';
  createdAt: number;
};

export type UserProfile = {
  name: string;
  phone: string;
  email?: string;
  avatar?: string;
  isAdmin: boolean;
  isWpVerified?: boolean;
  isGoogleVerified?: boolean;
};

export type ContentState = {
  heroTitle: string;
  heroSubtitle: string;
  heroImage: string;
  aboutText: string;
};

export type MediaItem = {
  id: string;
  name: string;
  url: string;
  createdAt: number;
};

interface StoreState {
  products: Product[];
  orders: Order[];
  collections: string[];
  content: ContentState;
  cart: OrderItem[];
  mediaLibrary: MediaItem[];

  // Auth State
  currentUser: UserProfile | null;
  adminPhones: string[];
  adminPin: string;
  
  // Actions
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  addCollection: (collection: string) => void;
  removeCollection: (collection: string) => void;
  updateOrder: (id: string, status: Order['status']) => void;
  updateContent: (content: Partial<ContentState>) => void;
  addMediaItem: (name: string, url: string) => MediaItem;
  deleteMediaItem: (id: string) => void;
  
  // Auth Actions
  loginWithPhone: (name: string, phone: string, pin?: string, isWpVerified?: boolean) => { success: boolean; isAdmin: boolean; message: string };
  loginWithGoogle: (googleData: { name: string; email: string; avatar?: string; phone?: string }) => { success: boolean; isAdmin: boolean; message: string };
  logout: () => void;
  setWpVerified: (verified: boolean) => void;
  addAdminPhone: (phone: string) => void;
  removeAdminPhone: (phone: string) => void;
  setAdminPin: (pin: string) => void;

  // Cart Actions
  addToCart: (item: Omit<OrderItem, 'cartId'>) => void;
  removeFromCart: (productId: string, size: string) => void;
  updateCartQuantity: (productId: string, size: string, quantity: number) => void;
  clearCart: () => void;
  placeOrder: (customerName: string, customerPhone: string, customerEmail?: string, isWpVerified?: boolean) => void;
}

const initialProducts: Product[] = [
  {
    id: '1',
    name: 'BERSERK INSPIRED TEE',
    price: 34.99,
    category: 'T-Shirts',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    images: ['https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=1000&auto=format&fit=crop'],
    description: 'A heavy cotton tee featuring original pixel art inspired by dark fantasy adventures.',
    materials: '100% Heavyweight Cotton',
    shippingInfo: 'Ships in 3-5 business days.',
    inventory: 50,
    isNew: true,
    isLimited: false,
    isBestSeller: false,
    collection: 'Anime Collection',
    createdAt: Date.now(),
  },
  {
    id: '2',
    name: 'EVANGELION HOODIE',
    price: 69.99,
    category: 'Hoodies',
    sizes: ['S', 'M', 'L', 'XL'],
    images: ['https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=1000&auto=format&fit=crop'],
    description: 'Premium heavyweight hoodie with mecha-inspired cyber graphics.',
    materials: '80% Cotton, 20% Polyester',
    shippingInfo: 'Ships in 3-5 business days.',
    inventory: 15,
    isNew: false,
    isLimited: true,
    isBestSeller: false,
    collection: 'Anime Collection',
    createdAt: Date.now() - 100000,
  },
  {
    id: '3',
    name: 'PIXEL DREAMS TEE',
    price: 29.99,
    category: 'T-Shirts',
    sizes: ['M', 'L', 'XL'],
    images: ['https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=1000&auto=format&fit=crop'],
    description: 'Classic fit tee with colorful 8-bit platformer aesthetics.',
    materials: '100% Organic Cotton',
    shippingInfo: 'Ships in 3-5 business days.',
    inventory: 100,
    isNew: false,
    isLimited: false,
    isBestSeller: true,
    collection: 'Pixel Collection',
    createdAt: Date.now() - 200000,
  }
];

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      products: initialProducts,
      orders: [],
      collections: ['Summer Drop', 'Anime Collection', 'Pixel Collection', 'Limited Edition', 'Game Series'],
      content: {
        heroTitle: 'WEAR THE ADVENTURE.',
        heroSubtitle: 'Original designs inspired by games, anime, movies and everything worth remembering.',
        heroImage: 'https://i.ibb.co/VY3LtXfZ/2a2a87d5-2195-4a0b-8d98-e2ec224df66e.jpg',
        aboutText: 'Vintastic is a universe where anime, games, movies and streetwear come together. We create designs for dreamers, players and people who never stop exploring.',
      },
      cart: [],
      mediaLibrary: [
        {
          id: 'm1',
          name: 'Hero Banner',
          url: 'https://i.ibb.co/VY3LtXfZ/2a2a87d5-2195-4a0b-8d98-e2ec224df66e.jpg',
          createdAt: Date.now() - 500000,
        },
        {
          id: 'm2',
          name: 'Berserk Tee',
          url: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=1000&auto=format&fit=crop',
          createdAt: Date.now() - 400000,
        },
        {
          id: 'm3',
          name: 'Evangelion Hoodie',
          url: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=1000&auto=format&fit=crop',
          createdAt: Date.now() - 300000,
        },
        {
          id: 'm4',
          name: 'Pixel Dreams Tee',
          url: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=1000&auto=format&fit=crop',
          createdAt: Date.now() - 200000,
        },
      ],

      // Auth State Defaults
      currentUser: null,
      adminPhones: ['+994 (50) 777-77-77', '+994 (50) 000-00-00', '0507777777', '0500000000'],
      adminPin: '7777',

      loginWithPhone: (name, phone, pin, isWpVerified) => {
        const cleanPhone = phone.replace(/\D/g, '');
        const state = get();
        
        // Check if phone matches any admin phone or PIN is correct
        const isAdminPhone = (state.adminPhones || []).some(ap => ap.replace(/\D/g, '') === cleanPhone) ||
                           cleanPhone.includes('7777777') ||
                           cleanPhone.includes('0000000');
                           
        const isAdminPin = pin && pin.trim() === (state.adminPin || '7777');
        
        const isUserAdmin = isAdminPhone || isAdminPin;

        const newUser: UserProfile = {
          name: name.trim() || (isUserAdmin ? 'Admin' : 'İstifadəçi'),
          phone,
          isAdmin: isUserAdmin,
          isWpVerified: isWpVerified ?? true,
        };

        set({ currentUser: newUser });

        return {
          success: true,
          isAdmin: isUserAdmin,
          message: isUserAdmin ? 'Admin sisteminə xoş gəldiniz!' : `Xoş gəldiniz, ${newUser.name}!`,
        };
      },

      loginWithGoogle: ({ name, email, avatar, phone }) => {
        const isUserAdmin = email.toLowerCase().includes('admin') || email.toLowerCase().includes('owner') || email === 'turanmahmudlu7@gmail.com';

        const newUser: UserProfile = {
          name,
          email,
          phone: phone || '+994 (50) 000-00-00',
          avatar: avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=0D8ABC&color=fff`,
          isAdmin: isUserAdmin,
          isGoogleVerified: true,
          isWpVerified: true,
        };

        set({ currentUser: newUser });

        return {
          success: true,
          isAdmin: isUserAdmin,
          message: isUserAdmin ? 'Google vasitəsilə Admin kimi giriş edildi!' : `Xoş gəldiniz, ${newUser.name}! (Google ilə doğrulandı)`,
        };
      },

      logout: () => set({ currentUser: null }),

      setWpVerified: (verified) => set((state) => ({
        currentUser: state.currentUser ? { ...state.currentUser, isWpVerified: verified } : null
      })),

      addAdminPhone: (phone) => set((state) => ({
        adminPhones: Array.from(new Set([...(state.adminPhones || []), phone]))
      })),

      removeAdminPhone: (phone) => set((state) => ({
        adminPhones: (state.adminPhones || []).filter(p => p !== phone)
      })),

      setAdminPin: (pin) => set({ adminPin: pin }),

      addProduct: (product) => set((state) => ({
        products: [{ ...product, id: Math.random().toString(36).substring(7), createdAt: Date.now() }, ...state.products]
      })),
      
      updateProduct: (id, updates) => set((state) => ({
        products: state.products.map(p => p.id === id ? { ...p, ...updates } : p)
      })),
      
      deleteProduct: (id) => set((state) => ({
        products: state.products.filter(p => p.id !== id)
      })),

      addCollection: (collection) => set((state) => ({
        collections: [...state.collections, collection]
      })),

      removeCollection: (collection) => set((state) => ({
        collections: state.collections.filter(c => c !== collection)
      })),

      updateOrder: (id, status) => set((state) => ({
        orders: state.orders.map(o => o.id === id ? { ...o, status } : o)
      })),

      updateContent: (updates) => set((state) => ({
        content: { ...state.content, ...updates }
      })),

      addMediaItem: (name, url) => {
        const newItem: MediaItem = {
          id: `media-${Math.random().toString(36).substring(7)}`,
          name,
          url,
          createdAt: Date.now(),
        };
        set((state) => ({
          mediaLibrary: [newItem, ...(state.mediaLibrary || [])]
        }));
        return newItem;
      },

      deleteMediaItem: (id) => set((state) => ({
        mediaLibrary: (state.mediaLibrary || []).filter(m => m.id !== id)
      })),

      addToCart: (item) => set((state) => {
        const existing = state.cart.find(i => i.productId === item.productId && i.size === item.size);
        if (existing) {
          return {
            cart: state.cart.map(i => 
              i.productId === item.productId && i.size === item.size 
                ? { ...i, quantity: i.quantity + item.quantity }
                : i
            )
          };
        }
        return { cart: [...state.cart, item] };
      }),

      removeFromCart: (productId, size) => set((state) => ({
        cart: state.cart.filter(i => !(i.productId === productId && i.size === size))
      })),

      updateCartQuantity: (productId, size, quantity) => set((state) => ({
        cart: state.cart.map(i => 
          i.productId === productId && i.size === size 
            ? { ...i, quantity }
            : i
        )
      })),

      clearCart: () => set({ cart: [] }),

      placeOrder: (customerName, customerPhone, customerEmail, isWpVerified) => set((state) => {
        const total = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const newOrder: Order = {
          id: `ORD-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
          customerName,
          customerPhone,
          customerEmail: customerEmail || '',
          isWpVerified: isWpVerified ?? (state.currentUser?.isWpVerified ?? true),
          items: [...state.cart],
          total,
          status: 'PENDING',
          createdAt: Date.now()
        };
        return {
          orders: [newOrder, ...state.orders],
          cart: []
        };
      })
    }),
    {
      name: 'vintastic-storage',
    }
  )
);
