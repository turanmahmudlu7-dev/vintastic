export interface GmailMessageHeader {
  name: string;
  value: string;
}

export interface GmailMessageSummary {
  id: string;
  threadId: string;
  snippet?: string;
  subject?: string;
  from?: string;
  date?: string;
}

/**
 * Creates RFC 2822 base64url encoded MIME string for Gmail API
 */
function createRawEmail(to: string, subject: string, htmlBody: string): string {
  const emailLines = [
    `To: ${to}`,
    'Content-Type: text/html; charset=utf-8',
    'MIME-Version: 1.0',
    `Subject: =?utf-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
    '',
    htmlBody
  ].join('\r\n');

  // Convert to Base64URL format required by Gmail API
  const base64 = btoa(unescape(encodeURIComponent(emailLines)));
  return base64
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Send an email via Gmail API using OAuth Access Token
 */
export async function sendGmailEmail({
  accessToken,
  to,
  subject,
  htmlBody
}: {
  accessToken: string;
  to: string;
  subject: string;
  htmlBody: string;
}): Promise<{ id: string; threadId: string }> {
  const raw = createRawEmail(to, subject, htmlBody);

  const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ raw })
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.error?.message || 'Gmail vasitəsilə e-poç göndərilərkən xəta baş verdi');
  }

  return response.json();
}

/**
 * Fetch recent inbox messages from Gmail API
 */
export async function fetchRecentGmailMessages(accessToken: string, maxResults = 10): Promise<GmailMessageSummary[]> {
  const listRes = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${maxResults}&q=label:INBOX`,
    {
      headers: { Authorization: `Bearer ${accessToken}` }
    }
  );

  if (!listRes.ok) {
    const err = await listRes.json();
    throw new Error(err.error?.message || 'Gmail mesajları çəkilə bilmədi.');
  }

  const listData = await listRes.json();
  if (!listData.messages || listData.messages.length === 0) {
    return [];
  }

  const summaries: GmailMessageSummary[] = [];

  // Fetch details for each message
  for (const msg of listData.messages.slice(0, maxResults)) {
    try {
      const msgRes = await fetch(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`,
        {
          headers: { Authorization: `Bearer ${accessToken}` }
        }
      );
      if (msgRes.ok) {
        const msgData = await msgRes.json();
        const headers: GmailMessageHeader[] = msgData.payload?.headers || [];
        const subject = headers.find(h => h.name.toLowerCase() === 'subject')?.value || '(Mövzusuz)';
        const from = headers.find(h => h.name.toLowerCase() === 'from')?.value || 'Bilinməyən';
        const date = headers.find(h => h.name.toLowerCase() === 'date')?.value || '';

        summaries.push({
          id: msgData.id,
          threadId: msgData.threadId,
          snippet: msgData.snippet,
          subject,
          from,
          date
        });
      }
    } catch {
      // Ignore individual item fetch failure
    }
  }

  return summaries;
}
